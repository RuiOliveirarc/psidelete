<form action="<?php echo e(route('generos.store')); ?>" method="post">

	<?php echo csrf_field(); ?>

	Designação: <input type="text" name="designacao">
	<br>
		<?php if($errors->has('designacao')): ?>
			Deverá indicar um designacao correto(Tem letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/generos/create.blade.php ENDPATH**/ ?>