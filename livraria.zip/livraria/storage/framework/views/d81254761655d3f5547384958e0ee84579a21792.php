<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<title>Index</title>
</head>
<body>
	<h2>Laravel</h2><br>
	<a href="/livros">Livros</a><br>
	<a href="/autores">Autores</a><br>
	<a href="/editoras">Editoras</a><br>
	<a href="/generos">Generos</a>
</body>
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.js"></script>
</html><?php /**PATH D:\livraria\resources\views/entrada.blade.php ENDPATH**/ ?>