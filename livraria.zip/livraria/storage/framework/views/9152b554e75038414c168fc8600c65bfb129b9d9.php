<ul>
<?php $__currentLoopData = $edicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
		<a href="<?php echo e(route('edicoes.show',['id'=>$edicao->id_livro])); ?>">
			<?php echo e($edicao->id_livro); ?>

		</a>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($edicoes->render()); ?><?php /**PATH D:\psiat4\livraria\resources\views/edicoes/index.blade.php ENDPATH**/ ?>