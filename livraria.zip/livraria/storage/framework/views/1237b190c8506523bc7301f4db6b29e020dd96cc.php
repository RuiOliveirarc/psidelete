ID:<?php echo e($genero->id_genero); ?><br>
Nome:<?php echo e($genero->designacao); ?><br>
Observacao:<?php echo e($genero->observacoes); ?><br>
<?php /**PATH C:\Users\Professor\Downloads\psiat6-main\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>