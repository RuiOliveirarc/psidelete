ID:<?php echo e($editora->id_editora); ?><br>
Nome:<?php echo e($editora->nome); ?><br>
Morada:<?php echo e($editora->morada); ?>


<?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/editoras/show.blade.php ENDPATH**/ ?>