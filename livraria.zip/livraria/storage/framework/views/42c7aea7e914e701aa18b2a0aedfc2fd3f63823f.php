ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>

<?php if(isset($livro->autor->nome)): ?>
	Autor:<?php echo e($livro->autor->nome); ?>

<?php endif; ?><?php /**PATH D:\psiat4\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>