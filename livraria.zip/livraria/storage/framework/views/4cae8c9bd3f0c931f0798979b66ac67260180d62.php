<form action="<?php echo e(route('generos.update', ['id'=>$genero->id_genero])); ?>" method="post">

	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	Designbação: <input type="text" name="designacao" value="<?php echo e($genero->designacao); ?>">
	<br>
		<?php if($errors->has('designacao')): ?>
			Deverá indicar uma designacao correto(Tem letras)<br>
		<?php endif; ?>

	Observações: <textarea name="observacoes"><?php echo e($genero->observacoes); ?></textarea>
	<br>

		<?php if($errors->has('observacoes')): ?>
			Deverá indicar observacoes correto<br>
		<?php endif; ?>
	
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psicreate-main\livraria\resources\views/generos/edit.blade.php ENDPATH**/ ?>